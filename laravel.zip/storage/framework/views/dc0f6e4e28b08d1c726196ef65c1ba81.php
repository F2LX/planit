<?php $__env->startSection('content'); ?>
<div class="p-5">
    <form action="/vendor/ads/add" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="w-100 d-flex flex-direction-column">
        <h2>Post New Ads</h2>
           
            <div class="add-order-form">
                <label for="">Title</label>
                <input placeholder="Input title here" type="text" name="title" id="">
            </div>
    
            <div class="add-order-form">
                <label for="">Description</label>
                <textarea name="description" id="" cols="20" rows="10"></textarea>
            </div>

            <div class="add-order-form">
                <label for="category">Category</label>
                <select name="category">
                    <option value="Wedding">Wedding</option>
                    <option value="Birthday Party">Birthday Party</option>
                    <option value="Summer Party">Summer Party</option>
                </select>
            </div>

            <div class="add-order-form">
                <label for="">Price</label>
                <input placeholder="Input title here" type="number" name="price" id="">
            </div>

            <div class="drop-box add-order-form">
                <label for="">Upload Image</label>
                    <label for="input-file" id="drop-area">
                        <input type="file" name="image" accept="image/*" id="input-file" hidden>
                        <div id="img-view">
                            <img src="<?php echo e(asset("img/UploadIcon.png")); ?>" alt="">
                            <p>Drag and drop or click here<br>to upload image</p>
                            <span>Upload any image from desktop</span>
                        </div>
                    </label>
            </div>
    </div>
    <button class="submit" type="submit">Submit</button>
    
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/vendor/advertisement.blade.php ENDPATH**/ ?>