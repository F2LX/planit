<?php $__env->startSection('content'); ?>
<div class="w-100 ml-3 overflow-x">

    <div class="wrapper-h50 d-flex mt-1">
        <div class="card-details">
            <img 
           class="width-pic" src="<?php echo e(Storage::url($vendor->img1)); ?>" alt="">
        </div>
        <div class="wrapper-details mr-3">
            <div class="card-details-2">
                <img 
           class="width-pic" src="<?php echo e(Storage::url($vendor->img2)); ?>" alt="">
            </div>
            <div class="card-details-2">
                <img 
           class="width-pic" src="<?php echo e(Storage::url($vendor->img3)); ?>" alt="">
            </div>
        </div>
    </div>
    <h2 class="ml-20 mb-2"><?php echo e($vendor->name); ?></h2>
    <div class="starbox mt-0">
        <span class="material-symbols-outlined" id="star-ikon">
            star_rate_half
        </span>
        <span class="material-symbols-outlined" id="star-ikon">
            star_rate_half
        </span>
        <span class="material-symbols-outlined" id="star-ikon">
            star_rate_half
        </span>
        <span class="material-symbols-outlined" id="star-ikon-gray">
            star
        </span>
        <span class="material-symbols-outlined" id="star-ikon-gray">
            star
        </span>
    </div>
    <button class="chatnow-box btn btn-green">Chat Now!</button>
    <div class="ml-20 mr-20">
        <div class="d-flex  text-justify">
            <p>
                <?php echo e($vendor->description); ?></p>
        </div>
        
<hr>    
        <div class="ads-wrapper">
            <img class="ads-thumbnail" src="<?php echo e(asset("img/homebg.png")); ?>" alt="">
        </div>
        <h2><?php echo e($ads->title); ?></h2>
        <p class="d-flex text-justify"><?php echo e($ads->title); ?></p>
        <hr>
        <h2 class="mt-10">Other Ads From Vendor Name</h2>
    </div>

    
    <div class="wrapper-details-2 d-flex">
        <?php $__currentLoopData = $adsbyvendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-details-3">
            <img class="card-thumbnail"src="<?php echo e(Storage::url($ad->image)); ?>" alt="">
            <div class="p-3">
                <h2 class=""><?php echo e($ad->title); ?></h2>
                <div class="">
                    <span class="material-symbols-outlined" id="star-ikon">
                        star_rate_half
                    </span>
                    <span class="material-symbols-outlined" id="star-ikon">
                        star_rate_half
                    </span>
                    <span class="material-symbols-outlined" id="star-ikon">
                        star_rate_half
                    </span>
                    <span class="material-symbols-outlined" id="star-ikon-gray">
                        star
                    </span>
                    <span class="material-symbols-outlined" id="star-ikon-gray">
                        star
                    </span>
                </div>
                <p><?php echo e(substr($ad->description, 0, 15) . "..."); ?></p>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/vendor/vendor-details.blade.php ENDPATH**/ ?>