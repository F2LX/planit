<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
    
    <title>Document</title>
</head>
<body class="dashboard">

    <div class="wrapper d-flex">
        <div class="menu">
            <h2>Vendor Area</h2>
            <ul class="menu-nav">
                <li><a href="">Home</a></li>
                <li><a href="">Order Summary</a></li>
                <li><a href="">Advertisement</a></li>
                <li><a href="">Wallet</a></li>
                <li><a href="">Contact Support</a></li>
            </ul>
        </div>
        <div class="content">
            
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/ui/dashboard.blade.php ENDPATH**/ ?>