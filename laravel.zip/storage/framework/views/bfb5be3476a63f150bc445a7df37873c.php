<?php $__env->startSection('content'); ?>
<div class="w-100 ml-3 overflow-x">

    <div class="wrapper-h50 d-flex mt-1">
        <div class="card-details">
            <img 
           class="width-pic" src="<?php echo e(asset("img/Rectangle 46.png")); ?>" alt="">
        </div>
        <div class="wrapper-details mr-3">
            <div class="card-details-2">

            </div>
            <div class="card-details-2">

            </div>
        </div>
    </div>
    <h2 class="ml-20 mb-2">Taylor Series Vendor</h2>
    <div class="starbox mt-0">
        <span class="material-symbols-outlined" id="star-ikon">
            star_rate_half
        </span>
        <span class="material-symbols-outlined" id="star-ikon">
            star_rate_half
        </span>
        <span class="material-symbols-outlined" id="star-ikon">
            star_rate_half
        </span>
        <span class="material-symbols-outlined" id="star-ikon-gray">
            star
        </span>
        <span class="material-symbols-outlined" id="star-ikon-gray">
            star
        </span>
    </div>
    <button class="chatnow-box btn btn-green">Chat Now!</button>
    <div class="ml-20 mr-20">
        <div class="d-flex  text-justify">
            <p>
                Taylor Series adalah mitra terpercaya Anda dalam menciptakan momen tak terlupakan dalam setiap acara. Dengan pengalaman bertahun-tahun dalam industri ini, kami telah menjadi pilihan utama bagi klien-klien yang menginginkan kualitas terbaik dalam setiap detail acara mereka. Dari pernikahan intim hingga acara korporat yang besar, kami menyediakan layanan yang disesuaikan dengan kebutuhan unik setiap klien. Dengan fokus pada kecermatan, kreativitas, dan profesionalisme, tim kami siap membawa visi Anda menjadi kenyataan. Jadikan setiap acara Anda istimewa dengan Vendor Taylor Series.</p>
        </div>
        
<hr>    
        <div class="ads-wrapper">
            <img class="ads-thumbnail" src="<?php echo e(asset("img/homebg.png")); ?>" alt="">
        </div>
        <h2>Ads Title Here</h2>
        <p class="d-flex text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam voluptatibus, dignissimos enim voluptatem sed eaque adipisci, laboriosam architecto veritatis beatae fugiat blanditiis! Eligendi recusandae repellat expedita harum voluptas quia animi?</p>
        <hr>
        <h2 class="mt-10">Other Ads From Vendor Name</h2>
    </div>

    
    <div class="wrapper-details-2 d-flex">
        <div class="card-details-3">
            <img class="card-thumbnail"src="<?php echo e(asset("img/homebg.png")); ?>" alt="">
            <div class="p-3">
                <h2 class="">Hello</h2>
            </div>
        </div>
        <div class="card-details-3">
            <img class="card-thumbnail"src="<?php echo e(asset("img/homebg.png")); ?>" alt="">
            <div class="p-3">
                <h2 class="">Hello</h2>
            </div>
        </div>
        <div class="card-details-3">
            <img class="card-thumbnail"src="<?php echo e(asset("img/homebg.png")); ?>" alt="">
            <div class="p-3">
                <h2 class="">Hello</h2>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/vendor/vendorDetails.blade.php ENDPATH**/ ?>