<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <form action="/vendor/ads/add" method="post">
            <?php echo csrf_field(); ?>
            <div class="w-100 d-flex flex-direction-column add-order-form">
                <h2 class="judul-form">Post New Schedule</h2>
                    <label for="">Event Name</label>
                    <input placeholder="Input event name here" type="text" name="event-name" id="" required>
            
                    <label for="">Description</label>
                    <textarea name="description" id="" cols="20" rows="10" placeholder="Input event description here"></textarea>

                    <label for="">Date</label>
                    <input type="date" name="date" id="" required>
        
                    <label for="">Time</label>
                    <input type="time" name="time" id="" required>

            </div>
            <button type="submit" class="btn btn-green mt-50">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/vendor/posting-schedule.blade.php ENDPATH**/ ?>