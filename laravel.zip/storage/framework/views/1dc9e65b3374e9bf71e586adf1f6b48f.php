<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <title>Plan It</title>

    
    <link rel="stylesheet" href="<?php echo e(asset("css/preloader.css")); ?>">

    <?php if(request()->is('/')): ?>
        <link rel="stylesheet" href="<?php echo e(asset("css/home.css")); ?>">
    <?php endif; ?>

    
    <?php if(request()->is('list')): ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/list.css")); ?>">
    <?php endif; ?>
   
    <link rel="stylesheet" href="<?php echo e(asset("css/mobile.css")); ?>">
</head>
<body>
    <nav class="d-flex main-nav justify-space-between align-center">
        <div class="title">
                <img src="<?php echo e(asset("img/logo.png")); ?>" alt="">
         </div>
            <ul class="d-inline text-right d-flex align-center">
                <li><a href="/">Home</a></li>
                <li><a href="/list">Vendors</a></li>
                <li><a href="/register">Register</a></li>

                <?php if(!auth()->user()): ?>
                <li><a href="/login" class="btn btn-nav d-flex align-center"><span class="material-symbols-outlined">
                    account_circle
                    </span><span class="ml-2">Login</span></a></li>
                <?php else: ?>
                    
                <li><a href="/user/profile" class="btn btn-nav d-flex align-center"><span class="material-symbols-outlined">
                    account_circle
                    </span><span class="ml-2">Profile</span></a></li>

                <?php endif; ?>
            </ul>
    </nav>
    <?php echo $__env->make('ui.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content-wrap">
        <?php if(!request()->is("/")): ?>
        <div class="nav-padding"></div>
        <?php endif; ?>
        <?php echo $__env->yieldContent("content"); ?>
    </div>
    <div class="bottom-nav d-flex w-100 flex-direction-row">
        <div class="bottom-child"><a href=""><span class="material-symbols-outlined">
            home
            </span><p>Home</p></a></div>
        <div class="bottom-child"><a href=""><span class="material-symbols-outlined">
            storefront
            </span><p>Vendors</p></a></div>
        <div class="bottom-child"><a href=""><span class="material-symbols-outlined">
            app_registration
            </span><p>Register</p></a></div>
        <div class="bottom-child"><a href=""><span class="material-symbols-outlined">
            person
            </span><p>Login</p></a></div>
    </div>
    <script src="<?php echo e(asset("js/preloader.js")); ?>"></script> 
</body>
</html><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/ui/main.blade.php ENDPATH**/ ?>