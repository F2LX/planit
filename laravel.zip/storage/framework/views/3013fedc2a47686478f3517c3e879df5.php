

<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <div class="d-flex align-center justify-content-between" id="searchbar-list">
            <input type="text" id="message-input" placeholder="Search">
            <button class="button-search">
                <span class="material-symbols-outlined" id="search-ikon">
                    search
                </span>    
            </button>
            
        </div>

        <div class="table-container">
            <table>
                <tr>
                    <th>No</th>
                    <th>Ads Title</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
                <?php if($ads): ?>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ad->id); ?></td>
                    <td><?php echo e($ad->title); ?></td>
                    <td>Rp<?php echo e($ad->price); ?></td>
                    <td>
                        <div class="d-flex button-action">
                            <a href="#popup" class="view">View</a>
                            <a href="#popupUpdate" class="update">Update</a>
                            <a href="#popupReport" class="report">Report</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </table>
        </div>
        <a href="/vendor/create-ads" class="add-order">Add New Ads</a>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/vendor/adslist.blade.php ENDPATH**/ ?>