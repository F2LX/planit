@extends('ui.user')

@section('content')
    <div class="p-5">
        <h2>Halo    </h2>
    </div>
@endsection