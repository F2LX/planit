<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <?php if($profile->address==null): ?>
            <p>Please fill your address</p>
        <?php endif; ?>
        <form action="/user/profile/post" method="post" enctype="multipart/form-data">
        <div class="d-flex align-center justify-content-center profile-container">
                <div class="drop-box-2">
                    <label for="masukin-file" id="drop-area-2">
                        <input type="file" accept="image/*" name="image" id="masukin-file" hidden>
                        <div id="img-view-2">
                            <img src="<?php echo e(Storage::url($profile->image)); ?>" alt="Gambar" class="avatarUp">

                        </div>
                            

                    </label>
                </div>            
            <div class=" profile-desc">
                
                    <?php echo csrf_field(); ?>
                    <label for="">Name:</label>
                    <br>
                    <input type="text" name="name" id="" value="<?php echo e($profile->name); ?>" required>
        
                    <br>
                    <br>
                    
                    <label for="">Address:</label>
                    <br>
                    <input type="text" name="address" id="" value="<?php echo e($profile->address); ?>" required>
        
                    <br>
                    <br>
        
                    <label for="">Phone:</label>
                    <br>
                    <input type="text" name="phonenumber" id="" value="<?php echo e($profile->phonenumber); ?>" required>
        
                    <br>
                    <br>
        
                    <label for="">Email:</label>
                    <br>
                    <input type="email" name="email" id="" value="<?php echo e($profile->email); ?>" required>

                    <div class="d-flex flex-direction-row profile-button">
                        <button type="submit" class="btn btn-green mt-70">Update Profile</button>
                            <a href="/logout" class="btn btn-red d-flex mt-70 align-center ml-5">
                                <span class="material-symbols-outlined">
                                    logout
                                </span>
                                Sign Out
                            </a>
            
                    </div>
                
            </div>
        </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('ui.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/user/profile.blade.php ENDPATH**/ ?>