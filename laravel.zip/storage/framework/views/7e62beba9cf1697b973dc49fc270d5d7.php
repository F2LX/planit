<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">

    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

    
    <link rel="stylesheet" href="<?php echo e(asset("css/animation.css")); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset("css/preloader.css")); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset("css/mobile.css")); ?>">
    
    <title>Plan It - Admin Area</title>
</head>
<body class="dashboard">

    <div class="wrapper d-flex">
        <div class="menu-padding"></div>
        <div class="menu">
            <div class="d-flex w-100 align-center">
                <img class="logo-sidebar" src="<?php echo e(asset("img/logo-green.png")); ?>" alt="">
            </div>
            <ul class="menu-nav">
                <li class="<?php echo e(request()->is('admin') ? 'active' : ''); ?>">
                    <a href="/admin" class="nav-link d-flex align-center flex-direction-row">
                        <span class="material-symbols-outlined">home</span>
                        <span class="nav-text">Home</span>
                    </a>
                </li>
                <li class="<?php echo e(request()->is('admin/order') ? 'active' : ''); ?>">
                    <a href="/admin/order" class="nav-link d-flex align-center flex-direction-row">
                        <span class="material-symbols-outlined">description</span>
                        <span class="nav-text">Order Summary</span>
                    </a>
                </li>
                <li class="<?php echo e(request()->is('admin/advertisement') ? 'active' : ''); ?>">
                    <a href="/admin/advertisement" class="nav-link d-flex align-center flex-direction-row">
                        <span class="material-symbols-outlined">ads_click</span>
                        <span class="nav-text">Advertisement</span>
                    </a>
                </li>
                <li class="<?php echo e(request()->is('admin/category') ? 'active' : ''); ?>">
                    <a href="/admin/category" class="nav-link d-flex align-center flex-direction-row">
                        <span class="material-symbols-outlined">
                            category
                            </span>
                        <span class="nav-text">Category</span>
                    </a>
                </li>
                <li class="<?php echo e(request()->is('admin/profile') ? 'active' : ''); ?>">
                    <a href="/admin/profile" class="nav-link d-flex align-center flex-direction-row">
                        <span class="material-symbols-outlined">account_circle</span>
                        <span class="nav-text">Profile</span>
                    </a>
                </li>
                <li class="<?php echo e(request()->is('admin/support-desk') ? 'active' : ''); ?>">
                    <a href="/admin/support-desk" class="nav-link d-flex align-center flex-direction-row">
                        <span class="material-symbols-outlined">contact_support</span>
                        <span class="nav-text">Dashboard Support</span>
                    </a>
                </li>
            </ul>
        </div>
        <?php echo $__env->make('ui.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content p-5">
            <div class="d-flex w-100">
                <button class="btn btn-minimize" id="dashboardMinimize"><span class="material-symbols-outlined">
                    menu
                    </span></button>
                <div class="d-flex align-center header-home w-100">
                    
                    <button class="back-to-without-back">
                        <p>Admin Area</p>
                    </button>
        
                    <h3>Hi, <span class="name-color"><?php echo e(auth()->user()->name); ?></span> !</h3>
                    <span class="material-symbols-outlined ml-5" id="zoom-ikon">
                        notifications
                    </span>   
                </div>
            </div>
            <hr>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    
    <script src="<?php echo e(asset("js/preloader.js")); ?>"></script>
    <script src="<?php echo e(asset("js/dashboard.js")); ?>"></script>
    <script src="<?php echo e(asset("js/uploadImage.js")); ?>"></script>
    <script src="<?php echo e(asset("js/uploadImage2.js")); ?>"></script>
    <script src="<?php echo e(asset("js/uploadImage3.js")); ?>"></script>
    <script src="<?php echo e(asset("js/uploadAvatar.js")); ?>"></script>
</body>
</html><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/ui/admin.blade.php ENDPATH**/ ?>