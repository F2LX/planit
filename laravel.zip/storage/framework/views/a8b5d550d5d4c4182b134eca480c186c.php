

<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <div class="d-flex">
            <div class=" w-50 img-listvendor">
                <img class="w-50" src="https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8cGFydHl8ZW58MHx8MHx8fDA%3D" alt="">
            </div>

            <div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/vendor/list.blade.php ENDPATH**/ ?>