<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset("css/animation.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/login.css")); ?>">
</head>
<body>
    <div class="wrapper d-flex justify-content-center align-center flex-wrap flex-direction-column">
        <div class="outerpanel">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <p>
                        Email telah didaftarkan sebelumnya.
                    </p>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="loginpanel register">
                <h2 id="login-text">Register</h2>
                <form class="d-flex flex-direction-column" action="/register/create" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="name">Name:</label>
                    <input class="form-text" type="text" name="name" id="" placeholder="Enter your name here" required>
                    <label for="phonenumber">Phone Number:</label>
                    
                    <input class="form-text" type="text" name="phonenumber" id="" placeholder="Enter your phonenumber here" required onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                    <label for="email">Email:</label>
                    <input class="form-text" type="email" name="email" id="" placeholder="Enter your email here..." required>
                    <label for="password">Password:</label>
                    <input class="form-text" type="password" name="password" id="password" placeholder="Enter your password here..." required>
                    <label for="role">Register As:</label>
                    <select name="role" id="role" class="form-text">
                        <option value="user">Buyer</option>
                        <option value="vendor">Vendor</option>
                        
                    </select>
                    <button class="loginbtn" type="submit">Register</button>
                </form>
            </div>
        </div>
        <p id="regtext">Already have an account? <a href="/login"><span id="register">Login Now!</span></a></p>
    </div>
</body>
</html><?php /**PATH C:\Users\felix\OneDrive\Desktop\Laravel\planIt\resources\views/register.blade.php ENDPATH**/ ?>